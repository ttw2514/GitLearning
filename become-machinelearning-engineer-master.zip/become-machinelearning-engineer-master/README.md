# become-machinelearning-engineer
My solutions for projects in Udacity MLND
